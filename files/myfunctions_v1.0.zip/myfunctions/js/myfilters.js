jQuery(document).ready(function($) {
    var originalCode = $('#myfilters_code').val();

    $('#myfilters_code').on('input', function() {
        var newCode = $(this).val();
        if (newCode !== originalCode) {
            $('#myfilters_save_button').css('background-color', 'red');
        } else {
            $('#myfilters_save_button').css('background-color', '#0085ba'); // Default blue color
        }
    });
});

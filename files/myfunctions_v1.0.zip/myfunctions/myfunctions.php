<?php
/**
 * Plugin Name: MyFunctions
 * Plugin URI: https://atomy.cloud
 * Description: A plugin to add custom code to the functions.php of the current theme.
 * Version: 1.0
 * Author: Philip Mello & ChatGPT
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class MyFunctionsPlugin {

    public function __construct() {
        add_action('admin_menu', array($this, 'MyFunctions_create_menu'));
        add_action('admin_enqueue_scripts', array($this, 'MyFunctions_enqueue_scripts'));
    }

    public function MyFunctions_create_menu() {
        add_menu_page(
            'MyFunctions',       // Page title
            'MyFunctions',       // Menu title
            'manage_options',  // Capability
            'MyFunctions',       // Menu slug
            array($this, 'MyFunctions_settings_page'), // Callback function
            'dashicons-editor-code',  // Icon
            100  // Position
        );
    }

    public function MyFunctions_enqueue_scripts($hook) {
        if ($hook !== 'toplevel_page_MyFunctions') {
            return;
        }
        wp_enqueue_script('MyFunctions-script', plugins_url('/js/MyFunctions.js', __FILE__), array('jquery'), '1.0', true);
        wp_enqueue_style('MyFunctions-style', plugins_url('/css/MyFunctions.css', __FILE__));
    }

    public function MyFunctions_settings_page() {
        if (isset($_POST['MyFunctions_code'])) {
            $code = stripslashes($_POST['MyFunctions_code']);
            file_put_contents(get_theme_file_path() . '/functions.php', $code, FILE_APPEND);
        }

        $functions_code = file_get_contents(get_theme_file_path() . '/functions.php');
        ?>
        <div class="wrap">
            <h1>MyFunctions - Add Custom Code</h1>
            <form method="post" action="">
                <textarea name="MyFunctions_code" id="MyFunctions_code" rows="20" style="width: 100%;"><?php echo esc_textarea($functions_code); ?></textarea>
                <br><br>
                <button type="submit" id="MyFunctions_save_button" class="button button-primary">Save</button>
            </form>
        </div>
        <?php
    }
}

new MyFunctionsPlugin();

jQuery(document).ready(function($) {
    var originalCode = $('#myfunctions_code').val();

    // Change button color when code is modified
    $('#myfunctions_code').on('input', function() {
        var newCode = $(this).val();
        if (newCode !== originalCode) {
            $('#myfunctions_save_button').css('background-color', 'red');
        } else {
            $('#myfunctions_save_button').css('background-color', '#0085ba'); // Default blue color
        }
    });

    // Handle preset selection and append the code
    $('#myfunctions_presets').change(function() {
        var preset = $(this).val();
        if (preset) {
            $.ajax({
                url: myfunctions_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'load_preset_code',
                    preset: preset
                },
                success: function(response) {
                    // Append the preset code to the existing code
                    var currentCode = $('#myfunctions_code').val();
                    $('#myfunctions_code').val(currentCode + '\n\n' + response);
                }
            });
        }
    });
});

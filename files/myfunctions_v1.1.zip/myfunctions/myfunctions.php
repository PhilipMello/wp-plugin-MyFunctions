<?php
/**
 * Plugin Name: MyFunctions
 * Plugin URI: https://atomy.cloud
 * Description: A plugin to add custom code to the functions.php of the current theme.
 * Version: 1.1
 * Author: Philip Mello & ChatGPT
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Enable debugging to identify the issue
ini_set('display_errors', 0);
error_reporting(E_ALL);

class MyFunctionsPlugin {

    public function __construct() {
        add_action('admin_menu', array($this, 'myfunctions_create_menu'));
        add_action('admin_enqueue_scripts', array($this, 'myfunctions_enqueue_scripts'));
        add_action('wp_ajax_load_preset_code', array($this, 'load_preset_code'));
    }

    public function myfunctions_create_menu() {
        add_menu_page(
            'MyFunctions',
            'MyFunctions',
            'manage_options',
            'myfunctions',
            array($this, 'myfunctions_settings_page'),
            'dashicons-editor-code',
            100
        );
    }

    public function myfunctions_enqueue_scripts($hook) {
        if ($hook !== 'toplevel_page_myfunctions') {
            return;
        }
        wp_enqueue_media(); // Enqueue WordPress media library
        wp_enqueue_script('myfunctions-script', plugins_url('/js/myfunctions.js', __FILE__), array('jquery'), '1.1', true);
        wp_enqueue_style('myfunctions-style', plugins_url('/css/myfunctions.css', __FILE__));

        // Add ajax URL for loading presets
        wp_localize_script('myfunctions-script', 'myfunctions_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php')
        ));
    }

    public function myfunctions_settings_page() {
        if (isset($_POST['myfunctions_code'])) {
            $code = stripslashes($_POST['myfunctions_code']);
            file_put_contents(get_theme_file_path() . '/functions.php', $code, FILE_APPEND);
        }

        $functions_code = file_get_contents(get_theme_file_path() . '/functions.php');
        ?>
        <div class="wrap">
            <h1>MyFunctions - Add Custom Code</h1>
            <form method="post" action="">
                <label for="myfunctions_presets">Choose a preset function:</label>
                <select id="myfunctions_presets">
                    <option value="">Select a preset...</option>
                    <option value="preset1">Custom Admin Login and Header Logo</option>
                    <option value="preset2">Custom file types (mime)</option>
                    <option value="preset3">Hide WordPress Version</option>
                </select>

                <textarea name="myfunctions_code" id="myfunctions_code" rows="20" style="width: 100%;"><?php echo esc_textarea($functions_code); ?></textarea>
                <br><br>
                <button type="submit" id="myfunctions_save_button" class="button button-primary">Save</button>
            </form>
        </div>
        <?php
    }

    // Load preset code and append it to the existing code
    public function load_preset_code() {
        $preset = isset($_POST['preset']) ? sanitize_text_field($_POST['preset']) : '';

        // Log any issues
        error_log('Preset selected: ' . $preset);
        $preset_path = plugin_dir_path(__FILE__) . 'presets/' . $preset . '.php';

        if (file_exists($preset_path)) {
            $preset_code = file_get_contents($preset_path);
            echo $preset_code;  // Echo preset code to append in AJAX
        } else {
            // Log if preset file is missing
            error_log('Preset file not found: ' . $preset_path);
        }

        wp_die(); // Always call wp_die() in Ajax functions
    }
}

new MyFunctionsPlugin();

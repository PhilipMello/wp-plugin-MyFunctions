// Hide WordPress Version
remove_action('wp_head', 'wp_generator');